<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="/p" method="post" enctype="multipart/form-data">
            <div class="row justify-content-center">
                <div class="col-md-10">
                    <div class="row">
                        <h1>Add new post</h1>
                    </div>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <label for="caption" class="col-md-4 col-form-label ">Post Caption</label>
                            <input id="email" type="text"
                             class="form-control <?php if ($errors->has('caption')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('caption'); ?>
                             is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="cptian"
                             value="<?php echo e(old('caption')); ?>" required autocomplete="caption"
                             autofocus>
                            <?php if ($errors->has('caption')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('caption'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <div class="row">
                            <label for="image" class="col-md-4 col-form-label ">Post Image</label>
                            <input id="image" type="file"
                                   class="form-control-file <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
                                   is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="image"
                                   required autocomplete="image"
                             autofocus>
                            <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
                            <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    <div class="row pt-5 ">
                        <button class="btn btn-primary">Add new post</button>
                    </div>
                    </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\insta\resources\views/posts/create.blade.php ENDPATH**/ ?>