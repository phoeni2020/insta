<?php echo e($id); ?>

<?php /**PATH C:\xampp\htdocs\insta\resources\views/profiles/tst.blade.php ENDPATH**/ ?>