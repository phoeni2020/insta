<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="/profile/save/<?php echo e($id); ?>" method="post" enctype="multipart/form-data">
            <div class="row justify-content-center">
                <div class="col-md-10">
                    <div class="row">
                        <h1>Create your profile</h1>
                    </div>
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <label for="caption" class="col-md-4 col-form-label ">title</label>
                        <input id="title" type="text"
                               class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                                   is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="title"
                               value="<?php echo e(old('title')); ?>" required autocomplete="title"
                               autofocus>
                        <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                        <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="row">
                        <label for="link" class="col-md-4 col-form-label ">url</label>
                        <input id="link" type="text"
                               class="form-control <?php if ($errors->has('link')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('link'); ?>
                                   is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="link"
                               value="<?php echo e(old('link')); ?>" required autocomplete="link"
                               autofocus>
                        <?php if ($errors->has('link')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('link'); ?>
                        <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="row">
                        <label for="caption" class="col-md-4 col-form-label ">description</label>
                        <input id="description" type="text"
                               class="form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                                   is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="description"
                               value="<?php echo e(old('description')); ?>" required autocomplete="description"
                               autofocus>
                        <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                        <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="row">
                        <label for="image" class="col-md-4 col-form-label ">Post Image</label>
                        <input id="image" type="file"
                               class="form-control-file <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
                                   is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="image"
                               required autocomplete="image"
                               autofocus>
                        <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="row pt-5 ">
                        <button class="btn btn-primary">Add new post</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\insta\resources\views/profiles/create.blade.php ENDPATH**/ ?>